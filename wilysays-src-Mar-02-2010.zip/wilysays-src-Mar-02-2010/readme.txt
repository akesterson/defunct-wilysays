webapp/

	this directory contains the PHP files that run the leaderboard. 
	Really simple stuff. Also contains the help files and such.

src/

	Contains the actual source files that the game was made from.

	*SHOULD* load right up and run in Flash CS3.
